package com.vr.askanything.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.vr.askanything.model.Question_Section1;

@Controller
@RequestMapping(value = "/ask")
public class HomeController {

	@RequestMapping(value = "/home" ,method = RequestMethod.GET)
	public String getHomePage(ModelMap model) {
		model.addAttribute("quest_section1",new Question_Section1());
		return "index";
	}
	
	@RequestMapping(value = "/question.htm", method = RequestMethod.GET)
	public String  getQuestion(ModelMap model) {
		model.addAttribute("quest_section1",new Question_Section1());
		return "question";
	}
	@RequestMapping(value = "questionPost.htm" ,method = RequestMethod.POST)
	public String questionPost(@ModelAttribute Question_Section1 question) {
		
		return "";
	}
}
