package com.vr.askanything.service;

import com.vr.askanything.model.Question_Section1;

public interface QuestionSectionService {

	public Question_Section1 postQuestion(Question_Section1 question_Section1);
}
