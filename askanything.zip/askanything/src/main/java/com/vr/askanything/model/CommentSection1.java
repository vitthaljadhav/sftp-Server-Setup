package com.vr.askanything.model;

import javax.persistence.Column;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Table(name = "COMMENET_SECTION1")
public class CommentSection1 {

	@Column(name = "COMMENT_SEQUENCE_NO")
	private String comment_sequenceNo;

	@Column(name = "COMMENT")
	private String comment;
	
	/*	@
		 * ManyToOne private Question_Section1 question_Section1;
		 */
	
	public String getComment_sequenceNo() {
		return comment_sequenceNo;
	}

	public void setComment_sequenceNo(String comment_sequenceNo) {
		this.comment_sequenceNo = comment_sequenceNo;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
