package com.vr.askanything.service.impl;

import com.vr.askanything.model.Question_Section1;
import com.vr.askanything.service.QuestionSectionService;

public class QuestionSectionServiceImpl implements QuestionSectionService {

	@Override
	public Question_Section1 postQuestion(Question_Section1 question_Section1) {
		
		return null;
	}

}
