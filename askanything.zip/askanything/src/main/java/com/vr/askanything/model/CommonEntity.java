package com.vr.askanything.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class CommonEntity {
	@Column(name = "CREATED_USER")
	private String createdUserName;

	@Column(name = "MODIFIY_USER")
	private String modifiyUserName;

	@Column(name = "CREATED_DATE")
	private Date createdDate;

	@Column(name = "MODIFY_DATE")
	private Date modifyDate;

	public String getCreatedUserName() {
		return createdUserName;
	}

	public void setCreatedUserName(String createdUserName) {
		this.createdUserName = createdUserName;
	}

	public String getModifiyUserName() {
		return modifiyUserName;
	}

	public void setModifiyUserName(String modifiyUserName) {
		this.modifiyUserName = modifiyUserName;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
}
