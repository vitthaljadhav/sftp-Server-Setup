package com.vr.askanything.util;

public class SequencePK {

}
