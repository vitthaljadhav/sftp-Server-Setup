package com.vr.askanything.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "QUESTION_SECTION1")
public class Question_Section1 {

	@Id
	@Column(name = "QUESTION_SEQUENCENO")
	private String question_sequenceNo;
	
	@Column(name = "QUESTION")
	private String question;

	@Column(name = "OPTION1")
	private String option1;

	@Column(name = "OPTION2")
	private String option2;

	@Column(name = "OPTION3")
	private String option3;

	@Column(name = "option4")
	private String option4;

	@Column(name = "FLAG")
	private String flag;

	@Column(name = "RIGHT_ANS")
	private String rightAns;

	@Column(name = "LIKE_COUNT")
	private int likecount;

	@Column(name = "USER_NAME")
	private String username;
	
	/*
	 * @OneToMany(cascade = CascadeType.ALL)
	 * 
	 * @JoinColumn(name="COMMENT_SEQUENCE_NO_PK") private List<CommentSection1>
	 * commentSection1;
	 */



	public String getQuestion_sequenceNo() {
		return question_sequenceNo;
	}

	public void setQuestion_sequenceNo(String question_sequenceNo) {
		this.question_sequenceNo = question_sequenceNo;
	}

	public String getOption1() {
		return option1;
	}

	public void setOption1(String option1) {
		this.option1 = option1;
	}

	public String getOption2() {
		return option2;
	}

	public void setOption2(String option2) {
		this.option2 = option2;
	}

	public String getOption3() {
		return option3;
	}

	public void setOption3(String option3) {
		this.option3 = option3;
	}

	public String getOption4() {
		return option4;
	}

	public void setOption4(String option4) {
		this.option4 = option4;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getRightAns() {
		return rightAns;
	}

	public void setRightAns(String rightAns) {
		this.rightAns = rightAns;
	}

	public int getLikecount() {
		return likecount;
	}

	public void setLikecount(int likecount) {
		this.likecount = likecount;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
}
